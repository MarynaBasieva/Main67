'use strict'

const { task } = require('gulp');

let gulp  = require('gulp');



gulp.task('mytask', gulp.series(function (){
    console.log('Привіт');
}));